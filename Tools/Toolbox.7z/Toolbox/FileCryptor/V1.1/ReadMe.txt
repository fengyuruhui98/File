FileCryptor

Fuction:
FileCryptor is a light weighted file encryptor/decryptor. It can be installed in a folder and all the files in the folder and sub-folders are managed by the application.

Installation:
1. Create a folder anywhere, including hard disk or USB disk.
2. Copy the executable file FileCryptor.exe into the folder.
3. Run FileCryptor.exe, input a password (which can be changed later), and remember the password firmly.

NOTE:
1. Do NOT rename the executable file name.
2. Do NOT copy the INI file when installing. The INI file will be created when you run the application first time.
3. Make a copy of the INI file, and store it in a safe place. If the INI file is lost, all the encrypted files can never be decrypted.
4. Do NOT install the application in the root folder (eg. c:\) of the system disk. Or improper operation may destroy the system.
5. Do NOT embed the encryption system into another, which makes the system complicated, though it works.

Usage:
1. To encrypt/decrypt files, select files in the file list pane, and click "Encrypt" or "Decrypt" button in the tool bar.
2. Click the "Exit" button to exit the application.
3. Select the files and click "Shred" button to shred the files. Please note the shredded files can NEVER be recovered by any tools. Be careful to use the function.
4. Click "Option > Mode > Simple" menu to switch to simple mode. In the simple mode, you can drag files in Explorer and drop the files into the baskets named "Encrypt", "Decrypt", and "Shred". To switch back to the normal mode, simply double click on any baskets. Pressing ALT-S switches to Simple mode, and pressing ALT-N switches to Normal mode.
5. To encrypt/decrypt all the files in the folder and sub-folders, use menu "Operate > Encrypt all" or "Operate > Decrypt all".
6. To stop the task immediately, double click the progress bar, or click "Operate > Interrupt".
7. To change the password, use menu "File > New password".
8. To change the language of the user interface, use menu "Option > Language > English".
9. Do not forget to click "Help > Tutorial" to get help.

Security:
1. The application will automatically exit after 5 minutes idle.

Thanks and enjoy!
Yanmiao Liu
yanmiao_liu(at)yahoo.com
8/24/2018

====================================================================================================

FileCryptor

功能：
FileCryptor 是一个轻量级文件加密/解密工具。可以安装在一个文件夹里，文件夹及子文件夹里的文件将由应用程序管理。

安装：
1. 在任何位置创建一个文件夹，包括硬盘或者U盘。
2. 复制执行文件 FileCryptor.exe 到文件夹里。
3. 运行 FileCryptor.exe，输入密码（可以以后再修改），并且牢牢记住密码。

！！！注意！！！
1. 不要给执行文件重命名。
2. 安装时不要复制 INI 文件。INI 文件将在第一次运行应用程序时创建。
3. 做一个 INI 文件的备份，并且保存在一个安全的地方。如果 INI 文件丢失，所有加密的文件将不能解密。
4. 不要将应用程序安装在系统盘的根文件夹（如：C:\）。否则，不恰当的操作可能摧毁整个系统。
5. 不要将加密系统互相嵌套，这会使系统变得很复杂，虽然系统能正常工作。

用法：
1. 要加密/解密文件，在文件列表中选择文件，然后点击工具栏中的“加密”或“解密”按钮。
2. 点击“退出”按钮退出应用程序。
3. 选择文件并点击“粉碎”按钮粉碎文件。请注意粉碎的文件不能被任何工具恢复。使用此功能时多加小心。
4. 点击“选项 > 模式 > 简单”菜单切换到简单模式。在简单模式下，可以从资源管理器中拖放文件到名为“加密”、“解密”和“粉碎”的篮子里。切换回正常模式，双击任何一个篮子即可。按 ALT-S 切换到简单模式，按 ALT-N 切换到正常模式。
5. 要加密/解密文件夹及子文件夹中所有文件时，使用菜单“操作 > 全部加密”或“操作 > 全部解密”。
6. 要立即停止任务，双击进度条，或点击“操作 > 中断”。
7. 修改密码使用菜单“文件 > 新密码”。
8. 改变用户界面的语言使用“选项 > 语言 > 英文”。
9. 别忘了点击“帮助 > 教程”获得帮助。

安全：
1. 应用程序将在 5 分钟空闲后自动退出。

谢谢！尽情享受吧！
刘宴淼
yanmiao_liu(at)yahoo.com
8/24/2018