# vpr_trans_tools

#### 介绍
{网易云音乐(ncm), QQ音乐(qmc, mflac, mgg), 酷狗音乐(kgm), 虾米音乐(xm), 酷我音乐(.kwm) }

#### 使用说明

https://unlock-music-ix.netlify.app/原工具网址，
py与bat为批处理工具，原工具无法做到批处理，每次运行只能输入一个文件。
